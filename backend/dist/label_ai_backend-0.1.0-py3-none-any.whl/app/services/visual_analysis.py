import logging
from pathlib import Path
import cv2 # OpenCV for image processing
import numpy as np
from typing import Dict, Any, Tuple, Optional
import asyncio # For running synchronous OpenCV tasks in a thread

from app.core.config import settings
from app.utils import image_utils # Assuming you have image loading and basic processing here
from app.utils.custom_exceptions import VisualAnalysisError
from app.api.v1 import schemas as api_schemas # For BoundingBox, etc.

logger = logging.getLogger(settings.APP_NAME)

# --- Constants (example, can be configurable) ---
DEFAULT_DPI = 300 # Assume this DPI if not provided, crucial for mm/pt conversions

# --- Helper Conversion Functions ---
def pixels_to_mm(pixels: float, dpi: int) -> float:
    if dpi <= 0: return 0.0
    return (pixels / dpi) * 25.4

def mm_to_pixels(mm: float, dpi: int) -> int:
    if dpi <= 0: return 0
    return int(round((mm / 25.4) * dpi))

def pixels_to_points(pixels: float, dpi: int) -> float:
    if dpi <= 0: return 0.0
    return (pixels / dpi) * 72

def points_to_pixels(points: float, dpi: int) -> int:
    if dpi <= 0: return 0
    return int(round((points / 72) * dpi))


async def measure_font_size(
    image_path: Path,
    text_roi: api_schemas.BoundingBox, # ROI where the text is located
    rule_condition: api_schemas.RuleCondition, # Contains expected size and unit
    image_dpi: int = DEFAULT_DPI
) -> Dict[str, Any]:
    """
    Measures the font size of text within a given ROI.
    Args:
        image_path: Path to the label image.
        text_roi: BoundingBox of the specific text to measure.
        rule_condition: The rule condition with expected font size details.
        image_dpi: DPI of the image for accurate conversion.
    Returns:
        A dictionary with "measured_size_mm", "status" ('correct', 'wrong'), "message".
    """
    logger.info(f"Measuring font size for ROI {text_roi} in image {image_path}")
    result = {"status": "wrong", "message": "Font size check not fully implemented or failed.", "measured_value_str": "N/A"}

    try:
        # This is a complex CV task. Placeholder logic:
        # 1. Load image
        img_np = await image_utils.load_image(image_path)
        
        # 2. Crop the ROI
        x, y, w, h = text_roi.x, text_roi.y, text_roi.width, text_roi.height
        if x < 0 or y < 0 or x + w > img_np.shape[1] or y + h > img_np.shape[0]:
            raise VisualAnalysisError(f"ROI {text_roi} is out of image bounds ({img_np.shape[1]}x{img_np.shape[0]}).")
        
        roi_img = img_np[y : y + h, x : x + w]

        # 3. Preprocess ROI for character segmentation (e.g., binarize)
        gray_roi = cv2.cvtColor(roi_img, cv2.COLOR_BGR2GRAY)
        # _, binary_roi = cv2.threshold(gray_roi, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
        # Adaptive thresholding might be better
        binary_roi = cv2.adaptiveThreshold(gray_roi, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                           cv2.THRESH_BINARY_INV, 11, 2)


        # 4. Find contours (potential characters/lines of text)
        #    For simplicity, let's assume the dominant character height in the ROI represents font height.
        #    A more robust method would involve line segmentation and character height estimation.
        #    The height of the ROI itself (h) could be a proxy for line height if the ROI is tightly bound.
        
        # Simplified: Use the ROI height as a proxy for max character height in pixels for now
        # This is a very rough approximation and needs significant improvement.
        # A better approach is to find contours of characters and measure their heights.
        estimated_char_height_pixels = h * 0.7 # Assume characters take up 70% of ROI height

        # Another placeholder: Find contours and get median height of taller contours
        contours, _ = cv2.findContours(binary_roi, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        char_heights_px = []
        if contours:
            for cnt in contours:
                _, _, _, ch = cv2.boundingRect(cnt)
                # Filter small noise contours, and contours that are too wide to be characters
                if ch > 5 and ch / roi_img.shape[1] < 0.8 : # Basic filtering
                    char_heights_px.append(ch)
            if char_heights_px:
                 estimated_char_height_pixels = np.median(char_heights_px) # Use median height
                 logger.debug(f"Estimated char height in pixels: {estimated_char_height_pixels} from {len(char_heights_px)} contours.")
            else:
                logger.warning(f"No suitable character contours found in ROI for font size estimation.")
                result["message"] = "No characters detected in ROI for font size measurement."
                return result
        else: # Fallback if no contours
            logger.warning(f"No contours found in ROI for font size estimation. Using ROI height as proxy.")


        # 5. Convert pixel height to the rule's specified unit (mm or pt)
        measured_size_unit = 0.0
        if rule_condition.font_size_unit == "mm":
            measured_size_unit = pixels_to_mm(estimated_char_height_pixels, image_dpi)
        elif rule_condition.font_size_unit == "pt":
            measured_size_unit = pixels_to_points(estimated_char_height_pixels, image_dpi)
        else: # Default to pixels if unit not supported, or raise error
            measured_size_unit = estimated_char_height_pixels
            result["message"] = f"Unsupported font size unit: {rule_condition.font_size_unit}. Measured in pixels."
            # Or raise VisualAnalysisError("Unsupported font size unit for measurement.")

        result["measured_value_str"] = f"{measured_size_unit:.2f} {rule_condition.font_size_unit or 'px'}"
        logger.info(f"Measured font size: {result['measured_value_str']}")

        # 6. Compare with rule_condition.font_size_value and operator
        expected_value = rule_condition.font_size_value
        op = rule_condition.font_size_operator

        match = False
        if expected_value is not None:
            if op == api_schemas.ComparisonOperator.EXACTLY:
                # Allow a small tolerance for "exactly" due to measurement inaccuracies
                tolerance = 0.1 * expected_value # e.g., 10% tolerance
                match = abs(measured_size_unit - expected_value) <= tolerance
            elif op == api_schemas.ComparisonOperator.MIN:
                match = measured_size_unit >= expected_value
            elif op == api_schemas.ComparisonOperator.MAX:
                match = measured_size_unit <= expected_value
            elif op == api_schemas.ComparisonOperator.BETWEEN:
                if rule_condition.font_size_value_upper is not None:
                    match = expected_value <= measured_size_unit <= rule_condition.font_size_value_upper
        
            if match:
                result["status"] = "correct"
                result["message"] = f"Font size {result['measured_value_str']} meets requirement '{op.value} {expected_value} {rule_condition.font_size_unit}'."
            else:
                result["status"] = "wrong"
                result["message"] = f"Font size {result['measured_value_str']} does not meet requirement '{op.value} {expected_value} {rule_condition.font_size_unit}'."
        else:
            result["message"] = "No expected font size value provided in rule."

        return result

    except VisualAnalysisError:
        raise
    except Exception as e:
        logger.error(f"Unexpected error measuring font size: {e}", exc_info=True)
        raise VisualAnalysisError(f"Unexpected error during font size measurement: {e}")


async def check_element_spacing(
    image_path: Path,
    element1_roi: api_schemas.BoundingBox,
    element2_roi: api_schemas.BoundingBox,
    expected_spacing_mm: float, # Example: expected spacing
    spacing_type: Literal["horizontal_gap", "vertical_gap"], # Example
    image_dpi: int = DEFAULT_DPI
) -> Dict[str, Any]:
    """
    Placeholder: Checks spacing between two elements.
    """
    logger.info(f"Checking spacing between ROIs {element1_roi} and {element2_roi}")
    result = {"status": "wrong", "message": "Spacing check not implemented.", "measured_value_str": "N/A"}
    # 1. Determine gap in pixels based on ROIs and spacing_type
    #    e.g., horizontal_gap = element2_roi.x - (element1_roi.x + element1_roi.width)
    # 2. Convert pixel gap to mm using image_dpi
    # 3. Compare with expected_spacing_mm (allow tolerance)
    # 4. Set status and message
    return result


async def verify_barcode_dimensions(
    image_path: Path,
    barcode_roi: api_schemas.BoundingBox, # ROI where barcode is expected/found
    expected_width_mm: float,
    expected_height_mm: float,
    tolerance_mm: float = 0.5,
    image_dpi: int = DEFAULT_DPI
) -> Dict[str, Any]:
    """
    Placeholder: Verifies barcode dimensions.
    """
    logger.info(f"Verifying barcode dimensions for ROI {barcode_roi}")
    result = {"status": "wrong", "message": "Barcode dimension check not implemented.", "measured_value_str": "N/A"}
    # 1. Detect barcode within barcode_roi (e.g., using pyzbar or other libraries).
    #    If no barcode_roi is given, scan whole image, but this is harder.
    # 2. Get bounding box of the detected barcode in pixels.
    # 3. Convert pixel width/height to mm using image_dpi.
    # 4. Compare with expected dimensions +/- tolerance_mm.
    # 5. Set status and message.
    # Example: Assume barcode_roi *is* the detected barcode's bounding box for now
    measured_width_px = barcode_roi.width
    measured_height_px = barcode_roi.height
    measured_width_mm = pixels_to_mm(measured_width_px, image_dpi)
    measured_height_mm = pixels_to_mm(measured_height_px, image_dpi)
    result["measured_value_str"] = f"W: {measured_width_mm:.1f}mm, H: {measured_height_mm:.1f}mm"

    width_match = abs(measured_width_mm - expected_width_mm) <= tolerance_mm
    height_match = abs(measured_height_mm - expected_height_mm) <= tolerance_mm

    if width_match and height_match:
        result["status"] = "correct"
        result["message"] = f"Barcode dimensions ({result['measured_value_str']}) match expected (W:{expected_width_mm}mm, H:{expected_height_mm}mm +/-{tolerance_mm}mm)."
    else:
        result["status"] = "wrong"
        result["message"] = f"Barcode dimensions ({result['measured_value_str']}) mismatch. Expected (W:{expected_width_mm}mm, H:{expected_height_mm}mm +/-{tolerance_mm}mm)."
        if not width_match: result["message"] += " Width incorrect."
        if not height_match: result["message"] += " Height incorrect."

    return result

# Add other visual check functions as needed based on RuleType enum
# e.g., check_logo_presence, check_color_accuracy, etc.
from typing import Literal # For Python < 3.9 compatibility with Literal
