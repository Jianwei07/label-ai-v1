import logging
from fastapi import APIRouter, UploadFile, File, Form, HTTPException, Depends, BackgroundTasks, status
from typing import Optional
from uuid import UUID

from app.core.config import settings
# from app.core.security import get_api_key # Uncomment if API key auth is used
from app.api.v1 import schemas # Use the alias for clarity
from app.services import (
    file_processing_service,
    ocr_service,
    pdf_parser_service, # If rules come as PDF
    visual_analysis_service,
    rule_engine_service
)
from app.utils.custom_exceptions import CoreServiceError

logger = logging.getLogger(settings.APP_NAME)
router = APIRouter()

@router.post(
    "/check",
    response_model=schemas.LabelAnalysisResult,
    summary="Analyze a Label Image Against Rules",
    description="Upload a label image and a set of rules (either as JSON in the form data or as a separate file upload) to perform regulatory compliance checks.",
    status_code=status.HTTP_202_ACCEPTED # Accepted for processing, result might take time
)
async def check_label_compliance(
    background_tasks: BackgroundTasks,
    label_image: UploadFile = File(..., description="The label image file (e.g., PNG, JPG)."),
    rules_json_str: Optional[str] = Form(None, description="RuleSet provided as a JSON string. Use this or rules_file."),
    rules_file: Optional[UploadFile] = File(None, description="A file (YAML/JSON) containing the RuleSet. Use this or rules_json_str."),
    sensitivity: Optional[int] = Form(50, ge=0, le=100, description="Global sensitivity for checking (0-100)."),
    # api_key: str = Depends(get_api_key) # Uncomment to enable API key auth
):
    """
    Endpoint to process a label image against a set of rules.
    It accepts the label image and rules (either as an embedded JSON string or a separate file).
    The actual processing can be offloaded to a background task.
    """
    logger.info(f"Received label check request for image: {label_image.filename}")

    if not label_image.content_type.startswith("image/"):
        logger.warning(f"Invalid label image content type: {label_image.content_type}")
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Label image must be an image file (e.g., PNG, JPG).")

    parsed_ruleset: Optional[schemas.RuleSet] = None

    if rules_json_str:
        try:
            parsed_ruleset = schemas.RuleSet.model_validate_json(rules_json_str)
            logger.info(f"Successfully parsed RuleSet from JSON string: {parsed_ruleset.name if parsed_ruleset else 'N/A'}")
        except Exception as e:
            logger.error(f"Error parsing rules_json_str: {e}", exc_info=True)
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=f"Invalid rules_json_str format: {e}")
    elif rules_file:
        if not (rules_file.filename.endswith(".json") or rules_file.filename.endswith(".yaml") or rules_file.filename.endswith(".yml")):
            logger.warning(f"Invalid rules file extension: {rules_file.filename}")
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Rules file must be JSON or YAML.")
        try:
            # Placeholder: In a real app, you'd save rules_file and parse it
            # For now, let's assume pdf_parser_service can handle UploadFile directly for JSON/YAML
            rules_content = await rules_file.read()
            # This service would need to handle bytes -> dict -> RuleSet
            parsed_ruleset = await pdf_parser_service.parse_rules_from_content(rules_content, rules_file.filename)
            logger.info(f"Successfully parsed RuleSet from file: {rules_file.filename}")
        except CoreServiceError as e:
            logger.error(f"Error parsing rules file '{rules_file.filename}': {e.message}", exc_info=True)
            raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=e.message)
        except Exception as e:
            logger.error(f"Unexpected error parsing rules file '{rules_file.filename}': {e}", exc_info=True)
            raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Could not process rules file.")
    else:
        logger.warning("No rules provided for label check.")
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Either rules_json_str or rules_file must be provided.")

    if not parsed_ruleset: # Should have been caught earlier, but as a safeguard
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="RuleSet could not be determined.")

    try:
        # 1. Save the uploaded label image temporarily
        saved_image_path = await file_processing_service.save_upload_file_temp(
            label_image, settings.UPLOADS_DIR
        )
        logger.info(f"Label image '{label_image.filename}' saved temporarily to {saved_image_path}")

        # 2. Create a unique analysis ID
        analysis_id = UUID(int=UUID().int) # Or however you generate IDs

        # 3. (Optional) Offload the heavy processing to a background task
        # For now, let's do it synchronously for simplicity, but background_tasks is available.
        # background_tasks.add_task(
        #     rule_engine_service.process_label_analysis,
        #     analysis_id=analysis_id,
        #     image_path=str(saved_image_path),
        #     ruleset=parsed_ruleset,
        #     sensitivity=sensitivity,
        #     original_filename=label_image.filename
        # )
        # return {"message": "Label analysis accepted and processing in background.", "analysis_id": analysis_id}

        # Synchronous processing for now:
        analysis_result = await rule_engine_service.process_label_analysis_sync(
            analysis_id=analysis_id,
            image_path=str(saved_image_path),
            ruleset=parsed_ruleset,
            sensitivity=sensitivity,
            original_filename=label_image.filename or "unknown_image"
        )
        logger.info(f"Label analysis completed for image: {label_image.filename}, Analysis ID: {analysis_id}")
        
        # 4. Clean up the temporary image file (could also be done by the service)
        # background_tasks.add_task(file_processing_service.cleanup_temp_file, saved_image_path)
        # For sync, do it now if rule_engine_service doesn't handle it
        await file_processing_service.cleanup_temp_file(saved_image_path)


        return analysis_result

    except CoreServiceError as e:
        logger.error(f"Core service error during label check: {e.message}", exc_info=True)
        raise HTTPException(status_code=e.status_code, detail=e.message, headers=e.headers)
    except HTTPException: # Re-raise HTTPExceptions from parsing etc.
        raise
    except Exception as e:
        logger.critical(f"Unexpected critical error during label check: {e}", exc_info=True)
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="An unexpected error occurred during label processing.")


@router.get(
    "/{analysis_id}/status",
    # response_model=schemas.LabelAnalysisStatus, # Define this schema if needed
    summary="Get Analysis Status (If using background tasks)",
    description="Poll this endpoint to get the status of a background label analysis task.",
    status_code=status.HTTP_200_OK
)
async def get_analysis_status(analysis_id: UUID):
    # This endpoint is more relevant if processing is truly asynchronous.
    # You would need a way to store and retrieve task statuses (e.g., in Redis or a DB).
    logger.info(f"Received status request for analysis ID: {analysis_id}")
    # Placeholder:
    # status_info = await rule_engine_service.get_analysis_status_from_storage(analysis_id)
    # if not status_info:
    #     raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Analysis ID not found or status not available.")
    # return status_info
    raise HTTPException(status_code=status.HTTP_501_NOT_IMPLEMENTED, detail="Status polling not fully implemented for synchronous processing.")

# Add more endpoints as needed, e.g., to retrieve full results if status endpoint only gives summary.
