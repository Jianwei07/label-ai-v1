import logging
import json
import yaml # Requires PyYAML: poetry add PyYAML
from pathlib import Path
from typing import Union, Dict, Any, Optional
from pydantic import ValidationError

from app.core.config import settings
from app.api.v1 import schemas as api_schemas # To parse into RuleSet
from app.utils.custom_exceptions import PDFParsingError, FileProcessingError # Renaming PDFParsingError to RuleParsingError might be better

logger = logging.getLogger(settings.APP_NAME)

async def parse_rules_from_content(
    file_content: bytes,
    filename: str
) -> Optional[api_schemas.RuleSet]:
    """
    Parses rule definitions from file content (JSON or YAML).
    Args:
        file_content: The raw byte content of the rule file.
        filename: The original filename, used to determine format.
    Returns:
        A RuleSet object if parsing is successful.
    Raises:
        RuleParsingError: If parsing fails or content is invalid.
        FileProcessingError: If filename is invalid.
    """
    logger.info(f"Parsing rules from content of file: {filename}")
    
    if not filename:
        raise FileProcessingError("Filename is required to determine rule file format.")

    try:
        file_suffix = Path(filename).suffix.lower()
        decoded_content = file_content.decode('utf-8')

        if file_suffix == ".json":
            rules_dict = json.loads(decoded_content)
        elif file_suffix in [".yaml", ".yml"]:
            try:
                rules_dict = yaml.safe_load(decoded_content)
            except yaml.YAMLError as e:
                logger.error(f"YAML parsing error for '{filename}': {e}", exc_info=True)
                raise PDFParsingError(f"Invalid YAML format in '{filename}': {e}")
        else:
            logger.warning(f"Unsupported rule file format for '{filename}': {file_suffix}")
            raise PDFParsingError(f"Unsupported rule file format: {file_suffix}. Please use JSON or YAML.")

        if not isinstance(rules_dict, dict):
            raise PDFParsingError(f"Parsed rule content from '{filename}' is not a valid dictionary structure.")

        # Validate and parse into the RuleSet Pydantic model
        parsed_ruleset = api_schemas.RuleSet.model_validate(rules_dict)
        logger.info(f"Successfully parsed and validated RuleSet '{parsed_ruleset.name}' from '{filename}'.")
        return parsed_ruleset

    except json.JSONDecodeError as e:
        logger.error(f"JSON parsing error for '{filename}': {e}", exc_info=True)
        raise PDFParsingError(f"Invalid JSON format in '{filename}': {e.msg}")
    except ValidationError as e: # Pydantic validation error
        logger.error(f"RuleSet validation error for '{filename}': {e.errors()}", exc_info=True)
        # You might want to format e.errors() for a more user-friendly message
        raise PDFParsingError(f"Invalid RuleSet structure in '{filename}': {e.errors()}")
    except UnicodeDecodeError as e:
        logger.error(f"Encoding error for '{filename}', ensure it's UTF-8: {e}", exc_info=True)
        raise PDFParsingError(f"Encoding error in '{filename}': ensure it's UTF-8 encoded.")
    except PDFParsingError: # Re-raise known parsing errors
        raise
    except Exception as e:
        logger.error(f"Unexpected error parsing rules from '{filename}': {e}", exc_info=True)
        raise PDFParsingError(f"An unexpected error occurred while parsing rules from '{filename}'.")


async def parse_rules_from_pdf_intent_document(pdf_path: Path) -> Optional[api_schemas.RuleSet]:
    """
    Placeholder: Parses rule definitions from a user-uploaded PDF intent document.
    This is a complex NLP/parsing task and would require a more sophisticated approach
    than simple text extraction.
    For MVP, focusing on JSON/YAML rules is simpler.
    Args:
        pdf_path: Path to the PDF file.
    Returns:
        A RuleSet object if parsing is successful.
    Raises:
        PDFParsingError: If parsing fails.
    """
    logger.info(f"Attempting to parse rules from PDF intent document: {pdf_path}")
    # This would involve:
    # 1. Using a library like `pdfplumber` or `PyMuPDF` to extract text, tables, etc.
    # 2. Applying heuristics, regex, or even ML models to identify rule statements.
    #    Examples:
    #    - "Font height exactly 3mm." -> RuleType.FONT_SIZE, value=3, unit="mm", operator="exactly"
    #    - "Ingredient list must match provided content exactly: [list text]" -> RuleType.EXACT_TEXT_MATCH
    # 3. Structuring these into RuleCondition objects and a RuleSet.
    
    # For now, this is a placeholder.
    logger.warning(f"Parsing rules from PDF documents ('{pdf_path}') is not fully implemented. Requires advanced NLP/parsing logic.")
    # Example dummy output:
    # return api_schemas.RuleSet(
    #     name=f"Rules extracted from {pdf_path.name}",
    #     conditions=[
    #         api_schemas.RuleCondition(type=api_schemas.RuleType.ELEMENT_PRESENCE, target_element_description="Company Logo", is_present=True),
    #         api_schemas.RuleCondition(type=api_schemas.RuleType.FONT_SIZE, target_element_description="Allergen Warning", font_size_value=2.0, font_size_unit="mm", font_size_operator=api_schemas.ComparisonOperator.MIN)
    #     ]
    # )
    raise PDFParsingError(f"Parsing rules from PDF ('{pdf_path.name}') is not implemented in this version.")

