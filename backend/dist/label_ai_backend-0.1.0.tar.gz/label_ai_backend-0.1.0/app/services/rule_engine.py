import logging
from pathlib import Path
from uuid import UUID
from typing import List, Dict, Any
import datetime

from app.core.config import settings
from app.api.v1 import schemas as api_schemas
from app.services import ocr_service, visual_analysis_service # , pdf_parser_service (if needed here)
from app.utils import text_utils, image_utils
from app.utils.custom_exceptions import RuleEngineError, OCRProcessingError, VisualAnalysisError

logger = logging.getLogger(settings.APP_NAME)

# Placeholder for storing analysis results if using background tasks and polling
# In a real app, this would be Redis, a database, or a more robust in-memory store.
ANALYSIS_RESULTS_CACHE: Dict[UUID, api_schemas.LabelAnalysisResult] = {}


async def process_label_analysis_sync(
    analysis_id: UUID,
    image_path: Path,
    ruleset: api_schemas.RuleSet,
    sensitivity: int, # 0-100, higher means more precise/strict
    original_filename: str
) -> api_schemas.LabelAnalysisResult:
    """
    Synchronously processes the label analysis.
    This is the main orchestration logic.
    """
    logger.info(f"Starting synchronous label analysis (ID: {analysis_id}) for image: {image_path.name}, RuleSet: {ruleset.name}, Sensitivity: {sensitivity}")
    
    highlights: List[api_schemas.HighlightedElement] = []
    overall_status: api_schemas.Literal["pass", "fail_critical", "fail_minor", "processing_error"] = "pass" # Default to pass
    error_messages = []
    matches_count = 0
    mismatches_count = 0
    processed_rules = 0

    try:
        # 1. Perform OCR on the entire image
        #    For complex layouts, OCR might need to be more targeted, or layout analysis performed first.
        #    Assume ocr_data is a list of OCRData objects with text and bounding boxes.
        try:
            all_ocr_data: List[ocr_service.OCRData] = await ocr_service.extract_text_from_image(image_path)
            if not all_ocr_data:
                logger.warning(f"OCR returned no data for image {image_path.name}. Some text rules may fail.")
                # Depending on rules, this could be a critical failure.
        except OCRProcessingError as e:
            logger.error(f"OCR processing failed for {image_path.name}: {e.message}", exc_info=True)
            error_messages.append(f"OCR Error: {e.message}")
            overall_status = "processing_error"
            all_ocr_data = [] # Ensure it's an empty list
            # Depending on severity, might return early
            # For now, continue to see if any non-OCR rules can be processed
            
        # TODO: Potentially perform layout analysis here to understand structure if needed
        # e.g., identify blocks like "Ingredient List", "Nutrition Table"

        # 2. Iterate through each rule condition in the RuleSet
        for i, condition in enumerate(ruleset.conditions):
            processed_rules += 1
            rule_id_ref = f"rule_{i+1}_{condition.type.value}" # Simple reference
            current_rule_highlight: Optional[api_schemas.HighlightedElement] = None
            target_found = False # Was the target element for the rule found?

            try:
                logger.debug(f"Processing rule (ID_ref: {rule_id_ref}): {condition.type.value} - {condition.description or condition.target_element_description or 'N/A'}")

                # --- Locate Target Element (if applicable) ---
                # This is a crucial and potentially complex step.
                # For now, assumes simple text search in OCR data if target_element_description is provided.
                # For visual rules without text cues, target_roi in rule might be used directly, or more complex detection.
                
                target_roi_for_visual_check: Optional[api_schemas.BoundingBox] = None
                ocr_match_for_target: Optional[ocr_service.OCRData] = None

                if condition.target_element_description and all_ocr_data:
                    # Find the target text in OCR results
                    for ocr_item in all_ocr_data:
                        # Simple containment check, can be made more robust (exact match, fuzzy, etc.)
                        # Use normalize_text for comparison
                        normalized_ocr_text = text_utils.normalize_text(ocr_item.text, case_sensitive=condition.case_sensitive if condition.case_sensitive is not None else True)
                        normalized_target_desc = text_utils.normalize_text(condition.target_element_description, case_sensitive=condition.case_sensitive if condition.case_sensitive is not None else True)

                        if normalized_target_desc in normalized_ocr_text: # Or exact match
                            ocr_match_for_target = ocr_item
                            target_roi_for_visual_check = api_schemas.BoundingBox(
                                x=ocr_item.left, y=ocr_item.top, width=ocr_item.width, height=ocr_item.height
                            )
                            target_found = True
                            logger.debug(f"Found target element '{condition.target_element_description}' via OCR: '{ocr_item.text}' at {target_roi_for_visual_check}")
                            break # Take the first match for simplicity

                # --- Apply Rule Logic based on Type ---
                if condition.type == api_schemas.RuleType.EXACT_TEXT_MATCH:
                    if not condition.expected_text:
                        raise RuleEngineError(f"Rule '{rule_id_ref}' (EXACT_TEXT_MATCH) is missing 'expected_text'.")
                    
                    found_text_in_ocr = False
                    if all_ocr_data: # Only proceed if OCR data is available
                        for ocr_item in all_ocr_data:
                            # For a general document search, check all items.
                            # If target_element_description was used, ocr_match_for_target would be set.
                            # Here, we search all OCR data for the expected_text.
                            if text_utils.compare_text_exactly(ocr_item.text, condition.expected_text, condition.case_sensitive if condition.case_sensitive is not None else True):
                                current_rule_highlight = api_schemas.HighlightedElement(
                                    rule_id_ref=rule_id_ref,
                                    bounding_box=api_schemas.BoundingBox(x=ocr_item.left, y=ocr_item.top, width=ocr_item.width, height=ocr_item.height),
                                    status="correct",
                                    message=f"'{condition.expected_text}' found as expected.",
                                    found_value=ocr_item.text,
                                    expected_value=condition.expected_text,
                                    confidence=ocr_item.confidence
                                )
                                matches_count += 1
                                found_text_in_ocr = True
                                break # Found it
                    
                    if not found_text_in_ocr:
                        # If text not found, we don't have a specific box to highlight red for the *missing* text easily.
                        # This highlights a challenge: how to show "missing expected text".
                        # Could be a general document-level flag or if a general area was defined for this text.
                        mismatches_count +=1
                        overall_status = "fail_minor" if overall_status == "pass" else overall_status
                        error_messages.append(f"Rule '{rule_id_ref}': Expected text '{condition.expected_text}' not found.")
                        # No specific highlight for missing text unless a search area was defined.

                elif condition.type == api_schemas.RuleType.FONT_SIZE:
                    if not target_roi_for_visual_check:
                        if condition.target_element_description:
                             error_messages.append(f"Rule '{rule_id_ref}' (FONT_SIZE): Target element '{condition.target_element_description}' not found by OCR to measure font size.")
                        else:
                            error_messages.append(f"Rule '{rule_id_ref}' (FONT_SIZE): Requires a target element description or ROI to measure font size.")
                        mismatches_count +=1
                        overall_status = "fail_minor" if overall_status == "pass" else overall_status
                    elif not (condition.font_size_value and condition.font_size_unit):
                         raise RuleEngineError(f"Rule '{rule_id_ref}' (FONT_SIZE) is missing 'font_size_value' or 'font_size_unit'.")
                    else:
                        font_check_result = await visual_analysis_service.measure_font_size(
                            image_path, target_roi_for_visual_check, condition
                        )
                        current_rule_highlight = api_schemas.HighlightedElement(
                            rule_id_ref=rule_id_ref,
                            bounding_box=target_roi_for_visual_check, # Highlight the text ROI
                            status=font_check_result["status"],
                            message=font_check_result["message"],
                            found_value=font_check_result["measured_value_str"],
                            expected_value=f"{condition.font_size_operator.value} {condition.font_size_value} {condition.font_size_unit}"
                        )
                        if font_check_result["status"] == "correct": matches_count +=1
                        else:
                            mismatches_count +=1
                            overall_status = "fail_minor" if overall_status == "pass" else overall_status
                
                elif condition.type == api_schemas.RuleType.ELEMENT_PRESENCE:
                    # If target_element_description was provided, target_found indicates presence.
                    element_actually_present = target_found
                    expected_to_be_present = condition.is_present if condition.is_present is not None else True

                    message = ""
                    status: api_schemas.Literal["correct", "wrong"] = "wrong"
                    box_to_highlight = target_roi_for_visual_check # Highlight if found

                    if element_actually_present == expected_to_be_present:
                        status = "correct"
                        message = f"Element '{condition.target_element_description}' presence is as expected ({'found' if expected_to_be_present else 'not found'})."
                        matches_count +=1
                    else:
                        status = "wrong"
                        message = f"Element '{condition.target_element_description}' presence mismatch: expected {'present' if expected_to_be_present else 'absent'}, but was {'present' if element_actually_present else 'absent'}."
                        mismatches_count +=1
                        overall_status = "fail_minor" if overall_status == "pass" else overall_status
                    
                    if box_to_highlight: # Only create highlight if we have a box
                         current_rule_highlight = api_schemas.HighlightedElement(
                            rule_id_ref=rule_id_ref,
                            bounding_box=box_to_highlight,
                            status=status,
                            message=message,
                            found_value="Present" if element_actually_present else "Absent",
                            expected_value="Present" if expected_to_be_present else "Absent"
                        )
                    elif status == "wrong" and expected_to_be_present: # Expected but not found, no box
                        error_messages.append(f"Rule '{rule_id_ref}': Element '{condition.target_element_description}' expected but not found.")


                elif condition.type == api_schemas.RuleType.BARCODE_DIMENSIONS:
                    if not target_roi_for_visual_check: # Assuming barcode is identified by target_element_description
                         error_messages.append(f"Rule '{rule_id_ref}' (BARCODE_DIMENSIONS): Target barcode element '{condition.target_element_description}' not found by OCR to measure dimensions.")
                         mismatches_count +=1
                         overall_status = "fail_minor" if overall_status == "pass" else overall_status
                    elif not (condition.expected_width_mm is not None and condition.expected_height_mm is not None):
                        raise RuleEngineError(f"Rule '{rule_id_ref}' (BARCODE_DIMENSIONS) is missing 'expected_width_mm' or 'expected_height_mm'.")
                    else:
                        barcode_check_result = await visual_analysis_service.verify_barcode_dimensions(
                            image_path, target_roi_for_visual_check, # This ROI should be refined to the actual barcode
                            condition.expected_width_mm, condition.expected_height_mm,
                            condition.tolerance_mm or 0.5
                        )
                        current_rule_highlight = api_schemas.HighlightedElement(
                            rule_id_ref=rule_id_ref,
                            bounding_box=target_roi_for_visual_check, # Highlight the located barcode
                            status=barcode_check_result["status"],
                            message=barcode_check_result["message"],
                            found_value=barcode_check_result["measured_value_str"],
                            expected_value=f"W:{condition.expected_width_mm}mm, H:{condition.expected_height_mm}mm"
                        )
                        if barcode_check_result["status"] == "correct": matches_count +=1
                        else:
                            mismatches_count +=1
                            overall_status = "fail_minor" if overall_status == "pass" else overall_status

                # TODO: Implement other rule types: SPACING, TRANSLATION_MATCH

                else:
                    logger.warning(f"Rule type '{condition.type.value}' (ID_ref: {rule_id_ref}) processing not implemented.")
                    error_messages.append(f"Rule '{rule_id_ref}': Type '{condition.type.value}' not implemented.")
                    # Consider this a mismatch or an error depending on policy
                    # mismatches_count +=1 
                    # overall_status = "fail_minor" if overall_status == "pass" else overall_status


                if current_rule_highlight:
                    highlights.append(current_rule_highlight)

            except (RuleEngineError, VisualAnalysisError, OCRProcessingError) as e: # Catch errors from this rule processing
                logger.error(f"Error processing rule (ID_ref: {rule_id_ref}): {e.message}", exc_info=True)
                error_messages.append(f"Rule '{rule_id_ref}' failed: {e.message}")
                mismatches_count +=1 # Treat rule processing error as a mismatch
                overall_status = "fail_critical" if "critical" in e.message.lower() else \
                                 "fail_minor" if overall_status == "pass" else overall_status
                # Optionally add a generic error highlight for the rule if possible
                # if target_roi_for_visual_check:
                #     highlights.append(api_schemas.HighlightedElement(
                #         rule_id_ref=rule_id_ref,
                #         bounding_box=target_roi_for_visual_check,
                #         status="wrong", # or "info" for processing error
                #         message=f"Error processing rule: {e.message[:100]}"
                #     ))


        # Final determination of overall_status based on counts if not already error/fail
        if overall_status == "pass" and mismatches_count > 0:
            overall_status = "fail_minor" # Or "fail_critical" if any mismatch is critical by policy

        # Construct the summary
        summary = {
            "total_rules_defined": len(ruleset.conditions),
            "rules_processed_attempted": processed_rules,
            "matches": matches_count,
            "mismatches_or_errors_in_rules": mismatches_count,
            "ocr_errors": 1 if any("OCR Error" in msg for msg in error_messages) else 0,
            "general_processing_errors": len([msg for msg in error_messages if "Rule" not in msg and "OCR Error" not in msg]),
            "error_messages": error_messages
        }
        
        result = api_schemas.LabelAnalysisResult(
            analysis_id=analysis_id,
            original_filename=original_filename,
            overall_status=overall_status,
            summary=summary,
            highlights=highlights,
            timestamp=datetime.datetime.now(datetime.timezone.utc).isoformat()
        )

        # Store for polling if this were async and polled
        # ANALYSIS_RESULTS_CACHE[analysis_id] = result
        logger.info(f"Analysis {analysis_id} completed. Overall Status: {overall_status}. Matches: {matches_count}, Mismatches: {mismatches_count}")
        return result

    except Exception as e:
        logger.critical(f"Critical unhandled error in rule engine for analysis {analysis_id}: {e}", exc_info=True)
        # Fallback error result
        return api_schemas.LabelAnalysisResult(
            analysis_id=analysis_id,
            original_filename=original_filename,
            overall_status="processing_error",
            summary={"error": "A critical unhandled error occurred during analysis.", "details": str(e)},
            highlights=[],
            timestamp=datetime.datetime.now(datetime.timezone.utc).isoformat()
        )

# async def get_analysis_status_from_storage(analysis_id: UUID) -> Optional[api_schemas.LabelAnalysisResult]:
#     """ Placeholder to retrieve status/result for polling. """
#     return ANALYSIS_RESULTS_CACHE.get(analysis_id)
